from services.recommendation_service import get_recommended_schemes
from services.scheme_service import search_schemes


class SchemeRecommendationAgent:
    """
    Retrieves relevant government schemes from the scheme database.

    This agent does NOT generate scheme information.
    It only returns schemes that actually exist in schemes.json.
    """

    def run(self, query: str) -> dict:
        if not isinstance(query, str) or not query.strip():
            return {
                "agent": "SchemeRecommendationAgent",
                "success": False,
                "count": 0,
                "schemes": [],
                "message": "Please provide a valid scheme-related query.",
            }

        query = query.strip()
        # First use the same partial search logic as the API.
        matched = search_schemes(query)

        # Then use the reusable profile helper for common profile queries.
        if not matched:
            matched = get_recommended_schemes({"occupation": query})

        # Deduplicate by stable ID.
        unique_schemes = []
        seen_ids = set()
        for scheme in matched:
            scheme_id = scheme.get("id")
            if scheme_id not in seen_ids:
                seen_ids.add(scheme_id)
                unique_schemes.append(scheme)

        if not unique_schemes:
            return {
                "agent": "SchemeRecommendationAgent",
                "success": True,
                "count": 0,
                "schemes": [],
                "message": (
                    "No relevant scheme was found in the available "
                    "government scheme database."
                ),
            }

        return {
            "agent": "SchemeRecommendationAgent",
            "success": True,
            "count": len(unique_schemes),
            "schemes": unique_schemes[:5],
            "message": (
                "Relevant schemes retrieved from the government "
                "scheme database."
            ),
        }
