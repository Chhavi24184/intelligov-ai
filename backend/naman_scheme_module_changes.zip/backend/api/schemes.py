from typing import Optional

from fastapi import APIRouter

from core.logger import logger
from services.scheme_service import (
    get_all_schemes,
    get_scheme_by_id,
    get_schemes_by_category,
    search_schemes,
)


router = APIRouter()


def _error(message: str) -> dict:
    """Keep scheme API errors consistent and JSON-friendly."""
    return {
        "success": False,
        "message": message,
        "schemes": [],
        # Backward-compatible key used by the older API shape.
        "data": [],
    }


@router.get("/schemes")
def schemes(category: Optional[str] = None):
    """Return all schemes, optionally filtered by category."""
    logger.info("Schemes API Called | Category: %s", category)

    if category is not None:
        category = category.strip()
        if not category:
            return _error("Invalid category parameter.")
        data = get_schemes_by_category(category)
    else:
        data = get_all_schemes()

    return {
        "success": True,
        "message": "Schemes fetched successfully.",
        "schemes": data,
        # Keep the old response key so existing frontend code does not break.
        "data": data,
    }


@router.get("/schemes/search")
def search(keyword: Optional[str] = None):
    """Search schemes by partial keyword in name, category, or description."""
    logger.info("Search API Called | Keyword: %s", keyword)

    if keyword is None or not keyword.strip():
        return _error("Search keyword is required.")

    if len(keyword.strip()) > 100:
        return _error("Search keyword is too long.")

    data = search_schemes(keyword)

    return {
        "success": True,
        "message": "Search completed successfully.",
        "schemes": data,
        # Backward-compatible key.
        "data": data,
    }


@router.get("/schemes/{scheme_id}")
def scheme_by_id(scheme_id: str):
    """Return one scheme by ID without allowing invalid input to crash the API."""
    try:
        parsed_id = int(scheme_id)
    except (TypeError, ValueError):
        return _error("Invalid scheme ID.")

    if parsed_id <= 0:
        return _error("Invalid scheme ID.")

    scheme = get_scheme_by_id(parsed_id)
    if scheme is None:
        return _error("Scheme not found.")

    return {
        "success": True,
        "message": "Scheme fetched successfully.",
        "scheme": scheme,
        "data": scheme,
    }
