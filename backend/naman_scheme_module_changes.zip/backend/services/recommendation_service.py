from typing import Any

from services.scheme_service import recommend_schemes


def get_recommended_schemes(profile: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Public reusable recommendation helper for agents and eligibility flows.

    Example profiles:
        {"occupation": "Student"}
        {"occupation": "Farmer"}
        {"occupation": "Job Seeker"}
        {"occupation": "Business", "gender": "Female"}
    """
    return recommend_schemes(profile)
