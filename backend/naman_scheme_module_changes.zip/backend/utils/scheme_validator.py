import json
from collections import Counter
from pathlib import Path
from typing import Any

from services.scheme_service import REQUIRED_FIELDS, DATA_FILE


ALLOWED_CATEGORIES = {
    "Agriculture",
    "Healthcare",
    "Housing",
    "Business",
    "Artisan",
    "Girl Child",
    "Pension",
    "Skill Development",
    "Education",
    "Employment",
    "Rural Employment",
    "Women Welfare",
    "Energy",
    "Agriculture Energy",
    "Maternity",
    "Insurance",
    "Street Vendors",
    "Entrepreneurship",
    "Apprenticeship",
    "Rural Skill Development",
    "Rural Livelihood",
    "Social Security",
    "Financial Inclusion",
}


def validate_scheme_data(data: list[dict[str, Any]]) -> dict[str, Any]:
    """Validate the scheme dataset and return a human-readable report."""
    issues: list[str] = []

    ids = [scheme.get("id") for scheme in data]
    names = [
        " ".join(str(scheme.get("name", "")).strip().lower().split())
        for scheme in data
    ]

    for index, scheme in enumerate(data, start=1):
        missing = [field for field in REQUIRED_FIELDS if field not in scheme]
        if missing:
            issues.append(f"Record {index}: missing fields: {', '.join(missing)}")

        for field in ("name", "category", "description", "eligibility", "state"):
            if not str(scheme.get(field, "")).strip():
                issues.append(f"Record {index}: empty {field}")

        documents = scheme.get("documents")
        if not isinstance(documents, list) or not documents:
            issues.append(f"Record {index}: documents must be a non-empty list")

        if scheme.get("category") not in ALLOWED_CATEGORIES:
            issues.append(
                f"Record {index}: unsupported category '{scheme.get('category')}'"
            )

    duplicate_ids = sorted(
        value for value, count in Counter(ids).items()
        if value is not None and count > 1
    )
    duplicate_names = sorted(
        value for value, count in Counter(names).items()
        if value and count > 1
    )

    if duplicate_ids:
        issues.append(f"Duplicate IDs: {duplicate_ids}")
    if duplicate_names:
        issues.append(f"Duplicate scheme names: {duplicate_names}")

    return {
        "valid": not issues,
        "total_schemes": len(data),
        "duplicate_ids": duplicate_ids,
        "duplicate_names": duplicate_names,
        "issues": issues,
    }


def validate_scheme_file() -> dict[str, Any]:
    with Path(DATA_FILE).open("r", encoding="utf-8") as file:
        data = json.load(file)
    return validate_scheme_data(data)
