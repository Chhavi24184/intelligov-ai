import json
import re
from pathlib import Path
from typing import Any


DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "schemes.json"

REQUIRED_FIELDS = (
    "id",
    "name",
    "category",
    "description",
    "eligibility",
    "documents",
    "state",
)

# Common user terms mapped to the canonical categories used by schemes.json.
CATEGORY_ALIASES = {
    "farmer": {"agriculture"},
    "farmers": {"agriculture"},
    "agriculture": {"agriculture"},
    "student": {"education", "skill development", "apprenticeship"},
    "students": {"education", "skill development", "apprenticeship"},
    "scholarship": {"education"},
    "education": {"education"},
    "health": {"healthcare"},
    "healthcare": {"healthcare"},
    "women": {"women welfare", "girl child", "maternity", "entrepreneurship"},
    "woman": {"women welfare", "girl child", "maternity", "entrepreneurship"},
    "girl": {"girl child"},
    "skill": {"skill development", "rural skill development"},
    "skills": {"skill development", "rural skill development"},
    "job seeker": {"employment", "skill development", "apprenticeship"},
    "job seekers": {"employment", "skill development", "apprenticeship"},
    "unemployed": {"employment", "skill development"},
    "employment": {"employment", "apprenticeship"},
    "business": {"business", "entrepreneurship"},
    "entrepreneur": {"business", "entrepreneurship"},
    "loan": {"business", "entrepreneurship", "financial inclusion"},
}


def _load_json() -> list[dict[str, Any]]:
    with DATA_FILE.open("r", encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, list):
        raise ValueError("Scheme data must be a JSON list.")

    return data


def _normalise(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def get_all_schemes() -> list[dict[str, Any]]:
    """Return all cleaned schemes."""
    return _load_json()


def get_scheme_by_id(scheme_id: int) -> dict[str, Any] | None:
    """Return one scheme by its unique numeric ID."""
    return next(
        (scheme for scheme in get_all_schemes() if scheme.get("id") == scheme_id),
        None,
    )


def get_schemes_by_category(category: str) -> list[dict[str, Any]]:
    """Return schemes whose category matches the supplied category."""
    category = _normalise(category)
    if not category:
        return []

    categories = CATEGORY_ALIASES.get(category, {category})

    return [
        scheme
        for scheme in get_all_schemes()
        if _normalise(scheme.get("category")) in categories
    ]


def search_schemes(keyword: str) -> list[dict[str, Any]]:
    """
    Case-insensitive partial search across scheme name, category and description.
    Multiple words are treated as an OR search so natural queries such as
    'PM Kisan' return useful results.
    """
    query = _normalise(keyword)
    if not query:
        return []

    words = [word for word in re.findall(r"[a-z0-9]+", query) if word]
    schemes = get_all_schemes()
    results = []

    for scheme in schemes:
        searchable = " ".join(
            _normalise(scheme.get(field))
            for field in ("name", "category", "description")
        )

        # A phrase is strongest. For multi-word queries, require all
        # meaningful terms so "PM Kisan" does not match every "PM" scheme.
        meaningful_words = [word for word in words if len(word) >= 3]
        if query in searchable or (
            meaningful_words
            and all(word in searchable for word in meaningful_words)
        ):
            results.append(scheme)

    return results


def recommend_schemes(profile: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Reusable profile-to-scheme recommender.

    Expected profile keys are flexible: occupation/role, gender, and optional
    state/age/income. It scores schemes by category and simple text matches.
    This is intentionally independent of the API so Chhavi's eligibility or
    agent layer can call it directly.
    """
    if not isinstance(profile, dict):
        raise ValueError("Profile must be an object.")

    occupation = _normalise(profile.get("occupation") or profile.get("role"))
    gender = _normalise(profile.get("gender"))
    state = _normalise(profile.get("state"))

    terms = set(re.findall(r"[a-z0-9]+", occupation))
    if occupation:
        terms.add(occupation)

    target_categories: set[str] = set()
    for term in terms:
        target_categories.update(CATEGORY_ALIASES.get(term, set()))
    if occupation:
        target_categories.update(CATEGORY_ALIASES.get(occupation, set()))

    if gender in {"female", "woman", "women", "girl"}:
        target_categories.update(CATEGORY_ALIASES["women"])

    recommendations = []

    for scheme in get_all_schemes():
        category = _normalise(scheme.get("category"))
        score = 0
        reasons = []

        if category in target_categories:
            score += 3
            reasons.append("Matches the user's profile")

        searchable = " ".join(
            _normalise(scheme.get(field))
            for field in ("name", "description", "eligibility")
        )

        for term in terms:
            if len(term) >= 3 and term in searchable:
                score += 1
                if "Relevant keywords found in scheme information" not in reasons:
                    reasons.append("Relevant keywords found in scheme information")
                break

        if state and _normalise(scheme.get("state")) not in {"all", "india", "central", state}:
            continue

        if score:
            result = scheme.copy()
            result["match_score"] = score
            result["eligibility_reasons"] = reasons
            recommendations.append(result)

    recommendations.sort(
        key=lambda item: (-item["match_score"], item.get("name", "").lower())
    )
    return recommendations
